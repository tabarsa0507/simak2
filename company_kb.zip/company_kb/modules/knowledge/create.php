<?php
require_once '../../config.php';
require_once '../../functions.php';
requireLogin();

$user = getCurrentUser();
$message = '';
$messageType = '';

// دریافت دسته‌بندی‌ها
$categories = $pdo->query("SELECT * FROM knowledge_categories ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_id = $_POST['category_id'] ?? null;
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    
    if (empty($title) || empty($content)) {
        $message = 'لطفاً عنوان و محتوا را وارد کنید.';
        $messageType = 'danger';
    } else {
        $stmt = $pdo->prepare("INSERT INTO knowledge_base (category_id, title, content, status, created_by) VALUES (?, ?, ?, 'pending', ?)");
        if ($stmt->execute([$category_id ?: null, $title, $content, $user['id']])) {
            $message = 'دانش با موفقیت ثبت شد و در انتظار تایید قرار گرفت.';
            $messageType = 'success';
            logActivity($user['id'], 'knowledge', 'create', "دانش جدید: {$title}");
        } else {
            $message = 'خطا در ثبت اطلاعات.';
            $messageType = 'danger';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت دانش جدید</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Vazirmatn', 'IRANSans', 'Tahoma', sans-serif; }
        body { background: #f0f2f5; }
        .sidebar { min-height: 100vh; background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%); padding: 20px; color: white; }
        .sidebar .nav-link { color: rgba(255,255,255,0.7); padding: 12px 18px; border-radius: 12px; margin-bottom: 5px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .sidebar .nav-link i { margin-left: 12px; width: 22px; }
        .main-content { padding: 30px; }
        .card-custom { background: white; border: none; border-radius: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        .card-custom .card-header { background: white; border-bottom: 2px solid #f0f2f5; padding: 18px 25px; font-weight: 700; border-radius: 20px 20px 0 0 !important; }
        .avatar-circle { width: 45px; height: 45px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 18px; background: linear-gradient(135deg, #667eea, #764ba2); }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar p-0">
                <?php include_once '../../sidebar.php'; ?>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4><i class="fas fa-plus me-2"></i> ثبت دانش جدید</h4>
                    <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-right"></i> بازگشت</a>
                </div>
                
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card-custom">
                    <div class="card-header">
                        <i class="fas fa-edit me-2"></i> فرم ثبت دانش
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">دسته‌بندی</label>
                                <select name="category_id" class="form-select">
                                    <option value="">بدون دسته‌بندی</option>
                                    <?php foreach($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">عنوان <span class="text-danger">*</span></label>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">محتوا <span class="text-danger">*</span></label>
                                <textarea name="content" class="form-control" rows="10" required></textarea>
                            </div>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> پس از ثبت، محتوای شما برای تایید به مدیر ارسال خواهد شد.
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ثبت دانش</button>
                            <a href="index.php" class="btn btn-secondary">انصراف</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>