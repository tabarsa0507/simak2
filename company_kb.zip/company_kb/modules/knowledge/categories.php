<?php
require_once '../../config.php';
require_once '../../functions.php';
requireLogin();

$user = getCurrentUser();
$message = '';
$messageType = '';

// عملیات CRUD دسته‌بندی
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $id = $_POST['id'] ?? 0;
    $name = trim($_POST['name']);
    $description = trim($_POST['description'] ?? '');
    
    if (empty($name)) {
        $message = 'نام دسته‌بندی را وارد کنید.';
        $messageType = 'danger';
    } else {
        try {
            if ($action == 'add') {
                $stmt = $pdo->prepare("INSERT INTO knowledge_categories (name, description) VALUES (?, ?)");
                $stmt->execute([$name, $description]);
                $message = 'دسته‌بندی با موفقیت اضافه شد.';
                logActivity($user['id'], 'knowledge_category', 'add', "دسته‌بندی: {$name}");
            } elseif ($action == 'edit') {
                $stmt = $pdo->prepare("UPDATE knowledge_categories SET name = ?, description = ? WHERE id = ?");
                $stmt->execute([$name, $description, $id]);
                $message = 'دسته‌بندی با موفقیت ویرایش شد.';
                logActivity($user['id'], 'knowledge_category', 'edit', "دسته‌بندی: {$name}");
            } elseif ($action == 'delete') {
                $stmt = $pdo->prepare("DELETE FROM knowledge_categories WHERE id = ?");
                $stmt->execute([$id]);
                $message = 'دسته‌بندی با موفقیت حذف شد.';
                logActivity($user['id'], 'knowledge_category', 'delete', "حذف دسته‌بندی ID: {$id}");
            }
            $messageType = 'success';
        } catch (PDOException $e) {
            $message = 'خطا: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

// دریافت لیست دسته‌بندی‌ها
$categories = $pdo->query("SELECT * FROM knowledge_categories ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت دسته‌بندی دانش</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Vazirmatn', 'IRANSans', 'Tahoma', sans-serif; }
        body { background: #f0f2f5; }
        .sidebar { min-height: 100vh; background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%); padding: 20px; color: white; }
        .sidebar .nav-link { color: rgba(255,255,255,0.7); padding: 12px 18px; border-radius: 12px; margin-bottom: 5px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .sidebar .nav-link i { margin-left: 12px; width: 22px; }
        .main-content { padding: 30px; }
        .card-custom { background: white; border: none; border-radius: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        .card-custom .card-header { background: white; border-bottom: 2px solid #f0f2f5; padding: 18px 25px; font-weight: 700; border-radius: 20px 20px 0 0 !important; }
        .avatar-circle { width: 45px; height: 45px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 18px; background: linear-gradient(135deg, #667eea, #764ba2); }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar p-0">
                <?php include_once '../../sidebar.php'; ?>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4><i class="fas fa-folder me-2"></i> مدیریت دسته‌بندی دانش</h4>
                    <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-right"></i> بازگشت</a>
                </div>
                
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <!-- فرم افزودن -->
                    <div class="col-md-4">
                        <div class="card-custom">
                            <div class="card-header">افزودن دسته‌بندی جدید</div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="add">
                                    <div class="mb-3">
                                        <label class="form-label">نام دسته‌بندی <span class="text-danger">*</span></label>
                                        <input type="text" name="name" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">توضیحات</label>
                                        <textarea name="description" class="form-control" rows="3"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-plus"></i> افزودن</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- لیست دسته‌بندی‌ها -->
                    <div class="col-md-8">
                        <div class="card-custom">
                            <div class="card-header">
                                <i class="fas fa-list me-2"></i> لیست دسته‌بندی‌ها
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>نام</th>
                                                <th>توضیحات</th>
                                                <th>عملیات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($categories as $cat): ?>
                                            <tr>
                                                <td><?php echo $cat['id']; ?></td>
                                                <td><strong><?php echo htmlspecialchars($cat['name']); ?></strong></td>
                                                <td><?php echo htmlspecialchars($cat['description'] ?? '-'); ?></td>
                                                <td>
                                                    <button class="btn btn-sm btn-warning edit-btn" 
                                                            data-id="<?php echo $cat['id']; ?>"
                                                            data-name="<?php echo htmlspecialchars($cat['name']); ?>"
                                                            data-description="<?php echo htmlspecialchars($cat['description'] ?? ''); ?>"
                                                            data-bs-toggle="modal" data-bs-target="#editModal">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-danger delete-btn"
                                                            data-id="<?php echo $cat['id']; ?>"
                                                            data-name="<?php echo htmlspecialchars($cat['name']); ?>"
                                                            data-bs-toggle="modal" data-bs-target="#deleteModal">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> ویرایش دسته‌بندی</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" id="edit-id">
                        <div class="mb-3">
                            <label class="form-label">نام دسته‌بندی</label>
                            <input type="text" name="name" id="edit-name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">توضیحات</label>
                            <textarea name="description" id="edit-description" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                        <button type="submit" class="btn btn-warning">ذخیره تغییرات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle"></i> حذف دسته‌بندی</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" id="delete-id">
                        <p>آیا از حذف دسته‌بندی <strong id="delete-name"></strong> اطمینان دارید؟</p>
                        <p class="text-danger">توجه: محتوای مرتبط با این دسته‌بندی حذف نمی‌شود.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                        <button type="submit" class="btn btn-danger">حذف</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('edit-id').value = this.dataset.id;
                document.getElementById('edit-name').value = this.dataset.name;
                document.getElementById('edit-description').value = this.dataset.description;
            });
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('delete-id').value = this.dataset.id;
                document.getElementById('delete-name').textContent = this.dataset.name;
            });
        });
    </script>
</body>
</html>